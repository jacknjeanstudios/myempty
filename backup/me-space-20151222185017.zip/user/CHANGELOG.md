# v1.1.2
## 11/12/2015

1. [](#bugfix)
    * Removing JSComments from dependencies due to numerous errors

# v1.1.0
## 11/12/2015

1. [](#new)
    * Fix for responsive videos
    * Couple fixes for JSComments
    * SimpleForm replaced with Forms plugin

# v1.0.2
## 09/21/2015

1. [](#new)
    * added SimpleForm landing page

# v1.0.1
## 04/07/2015

1. [](#bugfix)
    * Fixed for Grav 0.9.21 compatibility

# v1.0.0
## 04/07/2015

1. [](#new)
    * ChangeLog started...
