---
title: Social
taxonomy:
    category: sidebar
social: 
    - icon: facebook.png
      url: "https://www.facebook.com/JackPineDesign" 
    - icon: twitter.png
      url: "https://twitter.com/imJPWD"  
---


