---
title: 'About Me'
published: true
taxonomy:
    category:
        - sidebar
process:
    markdown: true
child_type: default
routable: true
cache_enable: true
visible: true
---

![About Me](about.png)

**My name is Karen**.  "There's an empty space in my heart.  It's purpose is not to be filled, but to teach me to let go." – unknown