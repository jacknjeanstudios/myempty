---
title: Day 20
date: 20:18 07/01/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Dear Mutty,

I have decided to write in the evenings now, because for realz after I get done writing and pouring my soul onto the screen in the morning it is such an emotional purge that I am exhausted. So evenings it is.

===

Today has been a good day thanks to Debra Roepke and Brenda Wilson. Very few tears. B. is doing well and they both miss you.

It is the first morning I slept past 8am since you left ... And the first morning I woke without you being the first thought.

My first thought was "Holy shit its nearly 8:30 and Deb will be here soon!" (does that even count?) ... mad dash to the door to pee the dogs... make coffee...and try to look like I was awake which I think was an epic fail especially when I looked in the mirror after she'd been her for quite awhile. Ugh. I don't think it counts.

I went out and rinsed the pool filter tonight, and watered the flowers and your angel garden. I am looking for a Hobbit hole now to fit in there... Deb and I came up with some good ideas on making one.

Why couldn't those little buggers live in trees, Mutty? It would be easier. But when have we ever been about "easy"?

Deb said she was going to read HP, (you captured another one) and I will try to hold her to it... who am I to talk? I have not read them, but I have seen all the movies along with LOTR. So I'm redeemed a little bit, eh Mutty?

I know, I know... I can hear you say even now - "How did I come from you and dad?"

I have the photo disk from the funeral home, so now I can make your "Life Book". I plan to ask Auntie Sandy to help me make your clothes into a quilt (or three)... that will give us something to do together, and I know she won't say no.

I thought about going to your room tonight... but to be honest I have had such a good day that I thought I might not want to ruin it. So for now... I will leave it be. Maybe when Willie and Josey come home we can go in together. Dad said he closed the door to it, and I got mad at him. Did I tell you that? I don't know why that would make me angry at him. But then where is the reason in any of this?

Maybe tomorrow I will try to venture in there alone. I'm afraid if I let the flood gates down I will never get them up again and I will die of dehydration all alone in the cave.

"It's crazy how much of yourself you can lose in a person." ~ Verticulars
I find that a lot of what I did in my daily routine was motivated by trying to get you well. Soaping, the environmental shit, researching, researching, researching... and I don't intend to stop any of that because I learned so much in that whole process,.. but I don't think I have the same fire and passion I had before.

Pr. Dave was here yesterday and brought a Curly Willow branch from the vase of one of your arrangements. I will definitely be planting that little bugger... just not sure where yet. We talked about the significance the number 7 in the bible and how this all time lined out.
Seven is the number of completeness. In my mind, there is no possible way any of this is coincidence.

I have rebuilt myself so many times, Heather ... and I just don't know if I have one more time in me and it had better be the last time... I need to coast from here out. I told dad last night that I wished the next 20 years to go by fast...and he said "Don't wish your life away." ‪#‎profounddadmoment‬

> "The Quest stands upon the edge of knife. Stray but a little and it will fail, to the ruin of all. Yet hope remains while the company is true. Do not let your hearts be troubled. Go now and rest for you are weary with sorrow and much toil. Tonight you will sleep in peace." ~<cite> LOTR</cite>


I love you, Mutty. So much, I love you.

Love, Mom