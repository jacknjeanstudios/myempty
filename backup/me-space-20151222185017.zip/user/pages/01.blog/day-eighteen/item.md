---
title: Day 18
date: 10:16 06/29/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Good Morning Mutty,

Well, I said goodbye to dad this morning, I know he is worried about me being here alone. As much as I don't want to be here, I know I need to be here.

===

On your last transplant, I told Dr. Chinny when he said you have a 50-50 chance of surviving the surgery and they hoped better than a 0% chance of recovery... I told him then that I believe we are here to learn and here to teach. If you die, then you have done all you came here to do.
I still believe that.

> I have unanswered prayers
I have trouble I wish wasn't there
And I have asked a thousand ways
That you would take my pain away" ~<cite> Your Hands by JJ Heller</cite>

The ache in my chest is heavy and I know its from a broken heart. Will I ever get to a point where you are not the first thing I think about in the morning... and the last thing at night? I am determined to do this without meds. Feeling broken is still feeling. It's something.

Planting your Angel tree, hunny, it was like a final act. I think that's why yesterday was so hard. I didn't go to Abby's shower. I should have but I just couldn't. I traded her shower for a nap where I got to see you. Selfish of me, I know. You had that quiet strength about you that in the face of shit, you just stayed graceful and kind. And you always tried to put others before yourself.

I remember when you two were little you were both going to live in New York and own a pet store. You always thought the city was so pretty.
I have showered. I have watered the porch flowers. I have yet to muster enough to water the inside plants. Clean carpets... and work. I have worked a little. Stringing thoughts together that are coherent are a little tough. My focus is lacking. A lot. I really need that to change.
I find when I write to you that I don't hurt as much. The ache lessens.
Goddamn this is a shitty way to get fodder for a book Heather .. and to lose weight.

I will be okay.

I deleted your stupid shows from the recording que last night. I may have to watch some of the shows you watched and I think I may have to invite all of your friend to watch with me. We'll see. Maybe we will do a dork weekend ... until I don't need to dork anymore.

I miss our talks. I miss them so much.

We talked about the most strangest of things... and teased each other. I miss the teasing. Willie is the only one who can tease me right now without it killing me...because he is Willie, and he has always teased me. And Matt. I love Matt. Such a good guy, like dad.

> When darkness comes upon you
And covers you with fear and shame
Be still and know that I'm with you
And I will say your name" ~<cite> The Fray</cite>

I have not been in your room since your funeral. I am still afraid if I go down there... it will be real. I don't want it to be real. I want to pretend you are still sleeping down there in the cave. I say good morning to you, and good night... but no more meds, eh Mutty? I am thankful you are done with the shit that made you so sick but kept you alive.

God, why is it so hard? I know your are better off where you are. I know that you are whole again. I know that you are radiant... and thriving. I know you are happy now. You looked amazingly happy yesterday... but I still want you here.

> You may say I'm a dreamer
But I'm not the only one" ~<cite> John Lennon</cite>

I want my broken heart not to hurt anymore. I want to get thru one day without crying.

I love you, Mutty. So much, I love you.

Love, Mom

