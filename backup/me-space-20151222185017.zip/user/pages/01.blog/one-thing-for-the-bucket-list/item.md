---
title: One Thing for the Bucket List
date: 10:10 06/15/2015
taxonomy:
    category: Morning Mutty
    tag: [journal]
---

Hi Mutty, 

Well we just got back from the funeral home, and I have to say it went far better than I expected. My legs buckled a little bit before we went thru the door, Rich Hantge was so kind. I think he might think I am crazy tho. I told him I gave Grammy-pants strict orders for her to not die in the next six months cuz for real, I can't do two. Its a rule. That's funny right? I know you think its funny...and you know how I am about my rules.

===

So I now have one thing for my bucket list: 
1. Crack up a funeral director before I die.

If he knew me like you do, he would have laughed.

I don't believe in death. I believe in God and you either have to believe in death or God but not both. Its not possible. Death is just the gate you have to travel thru to get to God, nothing more.

You weren't there. I looked at you, and you weren't there. I am good with that. I know you had to go, and that it was time. The decision was easy for us as a family. We couldn't have asked you to stay if it couldn't be good. And as good as the docs all are... it wasn't possible for it to be good. But you taught them, Mutty. You taught me. Thank you for choosing me to be your mom.

Well Sweetheart, I am finally going to try to get a nap before the party starts. And I think I might even be able to speak for you tomorrow. We'll see tho. So many people are grieving tho hunny. You looked so good on the outside just a few short weeks ago, but your insides were broken. If they knew how much you suffered, really suffered, and how physically broken you were, they would know this is a happy time for you, but not so much for us.

PS. Whisper in Rich's ear and tell him belly laughing is great for the soul. I'm kinda worried about those guys, too much seriousness might make a person nutz.
What do we say to death? Not today, Mutty. Not today.

