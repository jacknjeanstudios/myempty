---
title: Just One More Hug
date: 05:50 06/15/2015 
taxonomy:
    category: Morning Mutty
    tag: [journal]
---

Good morning, Mutty. It seems my body, in all its exhaustion, just cannot rest. I want to be awake. I want to feel something more than this gnawing gut wrenching ache.

===

I think you may have ruined coffee for me. I seem to be able to drink only a half cup at a time...and I loveses me some coffee. My guts rolls when I try to have morning coffee without you in my mornings. That better stop.
I am worried about Willie, hunny. He sleeps to your beloved Harry Potter movies. He stays up later than all of us alone...and its the alone times that are hardest of all. I think...I think if one more child of mine leaves I may die.
Matt and Josey are hanging in there. But then that's no surprise...Josey has the same grace you have only with a lot of "mean" to it.... and Matt, like dad, kinda takes care of all of us.

We decided we are having a "bill burning bonfire". OMG you would have loved that. I am going to have so much satisfaction now answering the phone when the debt collectors call for you. "Hello? Heather? Yeah she's here. Her urn doesn't get reception tho, she's dead." I am going to throw them squarely out of their comfort zone right into "fucked-up awkward land". The vultures. You would laugh at that.

Does this Time Turner need a battery? I still can't get it to work. I still am trying to turn back time because I miss you so much and even though we said everything there is to say that means anything.... I just want one more hug.
One more hurdle today... to stay conscious and to see you for the first time since you left. 

I love you Mutty. So much, I love you.
What do we say to death? Not today.
