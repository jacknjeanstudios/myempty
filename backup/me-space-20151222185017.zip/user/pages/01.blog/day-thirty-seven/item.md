---
title: Day 37
date: 22:28 07/17/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Hi Mutty,

Well, I haven't written for a few days, and its been a somewhat interesting week. Being Karen-centric is not as easy as it sounds

===

I am still trying to hack your gmail to see if there is anything in there I need to be aware of... God, you so sucked with passwords.
My pool is finally clear. Two people who have followed our story messaged me to help us out. Brad showed up yesterday, and today I swam for four hours with Anna. Maggie & Millie aren't so much diggin' it, but they'll live. We put them on the floaty.

Tuesday was a shitty day... an ambulance ride to ER for me... I put something in my mouth that I thought was something else, and it resulted in a trip to the ER with a pretty scary reaction. Dad got pulled out of jury duty to get to the hospital...I swear...now I know where you got your ditzi-ness from. It all ended well, with a lecture from the nice officer telling me not to put things in my mouth that I'm not for certain what it is. 52 years old and I act like I am two sometimes. I have no idea what I was thinking... but then that was part of what you loved about me.

Josey threatened to hire a day-care sitter because I break the pool rules and do stupid shit like that. The snot.

Willie and I are spending the day together tomorrow.I am kind of excited. I am finding them again, Heather... I am finding them, and missing you. I was so lost in you, and I didn't know how to draw that line. There just wasn't enough of me. I told dad tonight that I am terrified something will happen to one of them now... it never used to bother me to be alone and get some solitude...but now it throws the fear of God into me. I think it does Dad, too.

We went to Jenna Juergensen's wedding tonight. So beautiful. We got to sit with Pr. Jon, and Susan, and Pr. Mark...and Joan and Wade Padrnos. Dad and I didn't stay late... We wanted to come home and spend some time with Willie and Anna before she leaves for vacation to the Grand Canyon. I heart her... I think Willie heart's her too.

I finding myself going thru your blog still. Taking my time. Some thing's are heartbreaking, others funny... others deep and beautiful like you. I powered up your old phone and found a selfie of you and I in it. It made me cry.

And hello... there was nothing wrong with that phone other than the screen was cracked. Ugh... you could be such a shyster that way, Mutty... If I only had two dimes left to give I would have given them to you...but I would do that for all of those I love.

Well, its late here and I think after four hours of swimming, a wedding, a little visiting, and some water I am calling it a very good day.... one of the best ones I have had in a long, long, while.

I'll see you in my dreams. 

I love you Mutty. So much, I love you.

Love, Mom

