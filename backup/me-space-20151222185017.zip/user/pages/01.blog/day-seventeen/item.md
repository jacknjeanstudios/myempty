---
title: Day 17
date: 19:26 06/28/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Hi Mutty,

Well I finally got to see you in my dreams. Thank God for that. Really, thank Him for me... I needed to see you. So badly. You looked **so** good. So radiant. So beautiful. And your hair... oh wow... it was stunning- finally good hair days. I am glad to know you are helping youth still. A whole room full Heather Marie Eckstrom. That's my girl.

===

> Is it possible to love someone so completely that they simply can’t die?” ~<cite> Mark Helprin, Winter’s Tale</cite>

When I hugged you, I wanted to stay... I didn't want to wake up. I just wanted to spend a little more time with you. The healthy you. You looked so good. I expect to see you often. You hear me?

> Animals are such agreeable friends. They ask no questions, they pass no criticism." ~ <cite>unknown</cite>

The pool is full although it looks like lake water. I am getting tips on how to care for it. Now send me some hot days to raise the temp, so i can be in it. I bought Maggie & Millie a floating thing they can lay on too. Knowing them they will nag until I lift them in.

Millie finally has ventured out from under the bed. She is so lost. I tried to nap with her this morning after writing to you and she was having none of it. Such an independent little shit. So much like you.

> Being alone is not the same as being lonely. ~ <cite>Me</cite>

Tomorrow is my first "alone" day. Dad is going back to work...and I... well, I will work on what I can and then clean I suppose...and swim in the pool... and maybe sleep. I am so lacking sleep. Maybe I wouldn;t hurt so bad if I could get some decent sleep...and maybe the tears might not flow so often or abundantly. I am going to start my prayer time again. That was something I have been doing that not even you were aware of I think... you were first on my list of things I prayed about. Complete and total healing for you were the words I spoke when I talked with God each morning.

Be careful what you wish for eh, Mutty? I definitely got that. It really is what I wanted, so I guess I am good with it.

Dad is worried about me... so is Josey ... and I s'pose Willie is too. This day has to be conquered along with all alone days from here on out. I know I can do this and so what if I cry? It won't be because I am alone... it will be because I miss you so.

Well Mutty, the day wanes on and so must I.


I love you Mutty. So much, I love you.

Love, Mom

PS. See you in my dreams

