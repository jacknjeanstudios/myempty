---
title: Random Thoughts
date: 20:29 06/17/2015
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Hi Mutty,

Well, the hullabaloo has died down. The pit in my gut has not returned although the ache in my heart remains. The ache isn't for you though hunny, its for me. Its for Josey. Its for Willie. It's for Dad. Its for Matt. It's for Jamie, Anna, Jimmy, Cam, Gladys, Katie, and all of those who loved you most and best.

===

I cry a little here and a little there when the ache in my heart gets too heavy.
I find myself going back to the first transplant seven years ago. I remember the tear filled conversation we had after you woke from that first coma. You were so scared, you didn't know where you went. You kept asking me "Where did I go, Mom? I don't know where I went." It scared you so badly.

Yesterday would have marked the 7th year anniversary of the day you were admitted to the University Hospital in liver failure. I find myself wondering, what if Heather, what if the time you spent in the coma, you spent talking to God. Had I lost you back then, I think I may have gone mad. My biggest fear was you dying without knowing how much we loved you. You have to admit, we were not at a good place back then.

I find myself thinking that you were suppose to die back then. That maybe, just maybe, that time spent in the coma you spent talking with Jesus, and He gave you the choice to come back to try to make it right with all of us because you knew we couldn't handle any of it. The choice allowed us to mend everything and to be able to let go with as much grace as you had living for that 7 years. But the terms were you had come back in a broken body.

It would be just like you to take care of everyone else, and make sure we were okay at your own suffering. Did you do that hunny? Is it just a coincidence? If you did I am thankful you did...but at the same time ashamed that I wasn't strong enough to be okay. I'm sorry.

###FAMILY IS by A. Jedi

>Family is:
understanding, never demanding, 
all for one, one for all,
I will never leave you alone standing.
Family is:
One in itself, my love is your love,
your pain is my pain, my wealth is your wealth,
I promise never to leave you by yourself.
Family is:
never turning our backs, and never shames,
lend my helping hand and not a
finger pointing the blame.

I love you, Mutty. So much I love you.

What do we say to death? Not today.

Love, Mom

