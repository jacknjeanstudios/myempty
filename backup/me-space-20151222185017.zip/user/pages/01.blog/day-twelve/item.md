---
title: Day 12
date: 01:10 06/23/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Good Morning Mutty,

Dad and I went on another date last night. I'm not so sure its a date anymore ... I think we are attempting to escape but know we can't but we do even if only for a few hours.

It's funny the things we think about. I cried at dinner.

===

Dad and I went on another date last night. I'm not so sure its a date anymore ... I think we are attempting to escape but know we can't but we do even if only for a few hours.

It's funny the things we think about. I cried at dinner.

I took a nap until 2:45pm after I finished yesterdays post. I slept under your blue fuzzy blanket I bought you after the last xplant. I have always been a "blanky" person... when I was young I had one, and when my mother pulled it out of a box after I was married and handed it to me, just a rag, I nearly cried.

After grandpa died, and grammy-pants sent me the quilt back that I sewed for him, I slept under it until you left...and now I will sleep under yours. I like to pretend the warmth and security I feel from it is you.
Judge me. I don't really care.

I have not wandered to your room yet since the funeral - it was easy to enter before that - Jamie and Anna made it easy. I'm afraid if I do now, I may not be able to leave it. Did you know I took locks of your hair from you when you died? I have them in a baggie ... and I am tempted to open them and smell them...but afraid they will smell like plastic. Its kind of a dumb thing really. To be afraid that I will forget the scent of you. Were you real?

> One day, in retrospect, the years of struggle will strike you as the most beautiful.
> ~<cite> Sigmund Freud</cite>

Josey and I talked at days end yesterday. I told her how proud it makes me that you kids share a bond that was incredibly strong. She misses you, hunny. You were her best friend. You were Willie's, too. Each of you with your own incredible gifts ... when I look at all of you I think "How the hell did any of you drop out of me?" We talked about how there is no more worrying on you ... we talked about how this is what life must be like for most people who don't go thru a war zone like we have been thru ... I told her and Pr. Randy that I think this must be how it feels when the bombs stop falling and guns stop firing at wars end. That suddenly what you have been fighting for is just over. I liken this strangest of feelings to how that must feel. The over-ness of battles fought long and hard. Sudden silence. Weeping in the aftermath. Picking up the broken pieces, and trying to build something new from the ashes.

> So, this is my life. And I want you to know that I am both happy and sad and I’m still trying to figure out how that could be.
> ~<cite> Chbosky</cite>

During your service, when we said the Lord's prayer, Josey held her hand out to Willie and he low-fived her. ‪#‎dorkmoment‬

Do you remember when, you must have been about five, and it was the first day of Sunday school and you got a bite sized Snicker bar and Josey and Willie were grumbling about not getting one? You broke yours in half and gave half to Willie and half to Josey... and that's when a Mom knows she did right by her kids. You all took good care of each other ... for the most part. Getting you to eat mud by telling you they struck chocolate in the sandbox was not one of them tho.

Twenty or so years eh Mutty? I hope it goes by in a flash.

I love you Mutty. So much, I love you.

What do we say death? Not a damn thing - we aren't speaking.

Love, Mom

