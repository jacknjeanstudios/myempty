---
title: Day 10
date: 06:27 06/21/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Good Morning Mutty,

I spent the night with you in the family room. I feel closer to you in that room ... I think its because that's where we slept for a year when you were so sick. Me on one sofa, you on the other.... so freakin' sick and crazy out of your head with hepatic encephalopathy. As much as I don't miss those days, I miss them.

===

Today marks a first. First fathers day without you physically here. There will be two perspectives for us now - life before your death, and life after. It used to be life before the xplant, and life after. We humans are so dumb sometimes. As much as I want to tell you we won't, I don't think we are capable of being any other way.

Dad and I went on our first dinner "date" last night since I don't know when. When was the the last time we did anything together? I read a report on caregivers not so long ago... 90% of marriages fail where one partner is a full-time caregiver. Ahhh... we defy the odds once again, eh Mutty? God damn, we are good at defying odds.

He cries.

I wish everyone could have talked to you like we had talks. The things we said to each other ... crazy things. Magical things.

I told dad about the last conversation you and I had about your relationship with him. How you had told me how happy you were that you had finally reached that place of closeness you had always longed for... and how he was sending you text messages every morning and how much it meant to you. I am so glad you had that with him. I'm so glad he had that with you. I'm so glad you two healed.

I will make certain to whisper in his ear "Happy Fathers Day" from you ... and if I know Josey, she signed the card from you as well.

At dinner I asked him what he thought if we still drew your name at xmas, and whoever got your name, had to donate their designated amount to a charity of choice. And whose name you draw we will all come together to buy on your behalf for that person. I got met with stoic silence... sometimes I think that man thinks I'm bat shit crazy. Well, I am bat shit crazy... but in a good way. Good thing I asked in June... it will give him a few months to digest it. He's all about the digestion.

> Learning to let go should be learned before learning to get. Life should be touched, not strangled. You’ve got to relax, let it happen at times, and at others move forward with it.
> ~<cite> Ray Bradbury</cite>

It's going to be a glorious day.

We're doing our best, I promise.

What do we say to death? neener neener neeeeee - ner!

I love you Mutty. So much, I love you.

Love, Mom

