---
title: 'The Silence'
published: true
date: '13-06-2015 00:41'
taxonomy:
    category: 'Morning Mutty'
    tag:
        [stillness, journal]
process:
    markdown: true
child_type: default
routable: true
cache_enable: true
visible: true
author:
    name: 'Karen Eckstrom'
    description: 'When it is silent, I hear the pain in my heart...'
    url: '#'
    logo: x_logo.jpg
---

I am lost. I am broken. When it is silent, I hear the pain in my heart, and the gnawing ache in my gut. What am I gonna do on the days when I am alone? How am I gonna get thru them?
What do we say to death? Not today.
I miss you, Mutty.
