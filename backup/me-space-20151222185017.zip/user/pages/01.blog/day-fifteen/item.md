---
title: Day 15
date: 11:39 06/26/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Happy Noon Mutty,

Its been a rough morning here. A rough night last night, and I reckon it will be a tough day. I can't seem to find my footing. I can't seem to WANT to find my footing.

===

I miss you.

I dreamed we were in another hospital trying to find you another liver. I could have fixed that. I could have jammed phone lines. What I couldn't fix was an infection. I didn't plan for an infection. I always planned for another liver. Best goddamn laid plans, eh Mutty?

Lots of tears this morning. Lots.

My heart aches it is so broken.

I bought some of your music by the Avett Brothers.

> When I leave your arms

> The things I think of

> No need to get over alarmed

> I'm coming home." ~<cite> Avett Brothers</cite>

I think I might have to make William Eckstrom learn some of these songs. I find messages from you all over the place, I took your papers off the fridge, and I touch them because you did.

Somehow, Hunny, somehow I have to want to find purpose again ... and then I will find purpose again... its the wanting that's posing the challenge.

Willie and I talked last night - late. I got up to go to the bathroom, and he was there and we talked about the emptiness we feel in inside. I find myself wanting to cry at the most inopportune times. Like at dinner.
Dad told me no more dogs after these two die...I told him I will always have a dog. Its times when I feel so alone, that they come and love me, and just let me hurt, and not try to talk me out of it. They let the tears fall. Why are we so uncomfortable when we cry with each other? Why is it we try to stop the tears and deny the feelings? As much as I need them, I hate them ... but I need them.

> Letting go. Everyone talks about it like it’s the easiest thing. Unfurl your fingers one by one until your hand is open. But my hand has been clenched into a fist for…years now; it’s frozen shut. —<cite> Gayle Forman</cite>

I can never let go... it was you who was suppose to let go of me. I am so pissed its me letting go of you. What the hell Heather??

I love you, Mutty. So much, I love you.

What do we say to death? I'm ready when you are.

Love, Mom

