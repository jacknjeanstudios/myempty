---
title: One of THOSE Days
date: 14:53 10/15/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Dear Mutty,

Well, today has been one of THOSE days. You know, the ones where I get totally knocked off my feet when the realization comes slamming back that you are really gone.

===

For the most part, I tell myself that you are at a friends (not a lie) or that you are sleeping curled in a ball in your room... or that you are just in another room annoying the shit out of me like only you could do by being unproductive.

I have been thinking of the dust that must be collecting in your room. I don't have the chutzpah to dust it. It might just grow to look like Ms. Havishams wedding table. Decayed an dust covered. Kind of like her heart. Kind of like mine these days.

Patti Rutledge will rescue me.

Today, I was doing some digital organizing when I came across a video of you singing happy birthday to dad in the loudest, shittiest, off key voice you could muster.

I hate that song.

I don't know how it got in my inbox... I don't remember sending it to myself but the date is 6/13/2015 - two days after you died. And by the way...the 11th was a horseshit day to die on. Four months after you died, I turned 52...and from now on my birthday will forever mark the year + four months since you left. That's not even a little bit okay. Really Heather? This is hard enough without needing to make those kinds of connections.

I took a sip of coffee from the mug you bought me for my birthday three years ago when we were suppose to meet at Josey's for lunch, and you blew it. I was crushed that day.

You went to Shopko after lab draw in a last ditch effort to get something for me... and I was so mad at you that it didn't matter and now I think I would die of that cup broke.
Its funny how perspective changes things. There is before you died and after you died....and all of it is raw. So raw.

I have been drinking tea from your teapot. The Barnes and Noble one. I don't think I will ever be able to set foot in that place again... and it was ALWAYS a $100 bucks before we could leave. I just couldn't say "no" to you. Your pleasures were few and far between.

I find myself angry at you a lot. I don't blame you for going tho...I am angry that you left me here. This grief thing is a real bitch of a ride. I'll be glad when its over. So glad.

My bones hurt these days...or is it that my heart hurts so bad I feel it in my bones? I can barely tell the difference anymore.

I have figured out what I am going to do with your hair. I have been looking at old memorial jewelry and found some beautiful designs that I think I can do. I will put it in a locket. I intend to epoxy it in... but maybe not for a while so I can still touch part of you... and smell you. Its a weird mom thing.

I found my little laptop and fired it up after searching for it for two days. I went thru it and reclaimed it. I even launched into Netflix - FYI hunny, if there is a little arrow next to something, it means you can drop it down and make a selection.You used my profile to watch movies... now I am stuck with your crappy taste. Disney movies are not my thing. It ranks right up there with chick-flicks for me. I remember how, when you were little you would watch the same movie over and over and over again... and one day I asked you why? You said "Because the ending might change." I wonder if that's why people run old memories through their minds repeatedly... because their feeling might change?

One thing I am sure of - there is a God.... and we are eternal...and I will see you again. I don't believe in hell for the simple fact there can be nothing more painful than the loss of a child. You can take that to the bank.

Okay that was more than one thing...but all in the same line of thinking.

I am working on it hunny.... some days are harder, impossibly harder, than others. Today is one of the impossible days. I'll be better tomorrow. They are getting further and further apart. Thankfully.

I love you Mutty. So much, I love you.

Love, Mom.

