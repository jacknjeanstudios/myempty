---
title: 'The Star'
published: true
date: '31-10-2015 00:41'
taxonomy:
    category:
        - 'Morning Mutty'
    tag:
        - reflection
process:
    markdown: true
child_type: default
routable: true
cache_enable: true
visible: true
author:
    name: 'Karen Eckstrom'
    description: 'Even though my life may die. Do not worry, do not cry...'
    url: '#'
    logo: x_logo.jpg
---

I wrote this a long time ago when my dad died. After yesterday's FB Memory and a several hour weeping session. I decided to rework the design, and post the poem for others.I hope it helps someone out there... they are still here. Just not the way we need or want them to be..

===

![](unsplash_star.jpg)