---
title: 'Day 13'
date: '06:58 06/24/2015'
taxonomy:
    category:
        - 'Morning Mutty'
    tag:
        - journal
---

Good Morning Mutty,

Dad and I went on another date last night. I'm not so sure its a date anymore ... I think we are attempting to escape but know we can't but we do even if only for a few hours.

It's funny the things we think about. I cried at dinner.

===

Well I have been awake since before 6am, and just a bit ago I was attacked by Millie who was licking my ears, she had to go outside. Some things never change, eh Mutty?
I have watered the porch flowers, so beautiful this year. I have watered the dogs. I have transplanted the funeral plants to more sustainable containers. Grandma Max always had prayer plants. Tell her I expect them to be beautiful like hers always were. I'll let you negotiate that.

Last night I gathered your casket flowers, and the wreath from Josey, Willie & Matt and tossed them into the garbage. We will bring the baskets, and the casket saddle back to the florist for reuse for some other poor soul to use ... and slowly but surely that day is disappearing.

I talked to Ann yesterday. She called just to check up on me. I am going to miss her. She loved you hunny. So many of your care team truly loved you.
I cried yesterday. A lot.

Dad and I talk about things with you, some of the things that happened in this last two months now. We can speculate all we want but in the end it changes nothing.
We are like ghost people. Shells of our former selves. Empty, hollow shells. The space that you occupied in our lives is empty... it was such a big space.
Eat breakfast ... Exist ... Eat lunch ... Exist ... Eat supper ... Exist ... Go to bed ... Escape. Its the "existing's" that need work. Lotsa work.

So broken.

> My mission in life is not merely to survive, but to thrive; and to do so with some passion, some compassion, some humor, and some style. —<cite> Maya Angelou</cite>


So life goals:
* thrive and style need work. 
* crack up a funeral director.

Its going to be tough when I have a severe case of the fuckits and idontgiveashitz.
God, grant me the wisdom to recognize boundaries.

We decided last night not to take down the tree. We are going to rework the flower garden. Too many living creatures reside in it, and why should they lose a home because I have lost a daughter?

> Congratulations.
You have survived the war.
Now live with the trauma.
> —<cite> lorijenessanelson</cite>

I miss you mutty. So much I miss you.

What do we say to death? who?

Love, Mom

