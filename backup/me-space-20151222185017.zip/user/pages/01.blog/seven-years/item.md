---
title: Seven Years
date: 08:52 06/20/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Seven years ago today at approximately 3:45pm they wheeled Heather into surgery for her first liver transplant as we breathlessly waited for eleven hours in the family room surrounded by family and the laughter only family can bring at times like this.

===

At approximately 3:45pm today, her dad and I, alone, picked her up from the funeral home and brought our baby girl home again.

There is no possible way this is coincidence.

All is as it should be.

> I know you’ve lost someone and it hurts. You may have lost them suddenly, unexpectedly. Or perhaps you began losing pieces of them until one day, there was nothing left. You may have known them all your life or you may have barely known them at all. Either way, it is irrelevant — you cannot control the depth of a wound another soul inflicts upon you.

> Which is why I am not here to tell you tomorrow is another day. That the sun will go on shining. Or there are plenty of fish in the sea. What I will tell you is this; it’s okay to be hurting as much as you are. What you are feeling is not only completely valid but necessary — because it makes you so much more human. And though I can’t promise it will get better any time soon, I can tell you that it will — eventually. For now, all you can do is take your time. 
Take all the time you need.

> ~<cite> Lang Leav</cite>

I love you Mutty, so much, I love you. Welcome home hunny.

You. Are. Healed.

What do we say to death? Not today, not tomorrow, not ever.

God totally has this.

