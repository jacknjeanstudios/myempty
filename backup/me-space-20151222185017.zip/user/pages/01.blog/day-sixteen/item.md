---
title: Day 16
date: 07:44 06/27/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Good Morning Mutty,

Well, I got thru last night ... I wasn't going to go people-ing because yesterday was so rough. I forgot what a healing balm being with people you love and adore can be on your soul. (Note to self.)

===

Tomorrow is Abbey's bridal shower.

We laughed about you. A lot, about you. I hope you were there. I can finally tell stories on you without the repercussions of hurting your feelings. I love telling the stories of you and your shenanigans in your teenage years. Not so funny then, but OMG hilarious now. Someday Mutty ... its all going in a book. But first I have to arrive at where I am heading and I guess I won't know where that is until I get there.

> Love arrives safely with suitcase in tow.
Carrying with her the good things we know.
A reason to live and a reason to grow.
To trust. To hope. To care." ~<cite> Avett Brothers</cite>

I'm getting a pool. We are setting it up today if we can find one. So begins the next chapter, Mutty. Its my first future forward decision and step. It got a lot inebriated out last night, and of course I drank ice water... and everyone was in the right mood to all get on board.
I remember how when we would go out we would people watch and how you would laugh and slap your knee at the silliness of it all. I finally understand why I get sick before ever feeling "buzzed" ... I'm pretty sure some thought I was a prude.

The ache in my heart is better today ... but if I know grief, I know it will be back to squeeze the shit out of it several times a day just to let me know its knee bending power.

It still comes in waves.

> I always marvel at the humans’ ability to keep going. They always manage to stagger on even with tears streaming down their faces. ~ <cite>Markus Zusak, The Book Thief</cite>

I don't regret any of it, hunny. I'm so thankful you were mine and that you belonged to us, and that it was us that got to walk with you to deaths door. As much as I hate it, I'm thankful it was us.

> Smile. God selected you ... because he knew you could handle it. ~ note from <cite>Patti Rutledge</cite>

I love you, Mutty. So much I love you.

What do we say to death? not today.

Love, Mom

