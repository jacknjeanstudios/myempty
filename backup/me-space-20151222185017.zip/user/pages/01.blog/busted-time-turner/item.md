---
title: Not Today...
date: 21:54 06/14/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Did you break the Time Turner? The damn thing won't work. It doesn't turn back time at all. Such bullshit.

===

Today we went shopping for my clothes and for Josey's clothes. You would have loved this trip. Josey and I spent the day in St. Cloud where she got clothes, and then we had pedicures. I know you don't need a pedicure anymore, but I can't help but think how much you would have loved it.

Then we went to Crystal to shop for me. I bawled all the way thru the transaction. Tomorrow is coming like a freight train straight out of hell and while I am excited on one hand for your final party knowing how grand you are going to look, I am terrified on the other. Two more hurdles for me, Mutty. Seeing you for the first time since you left and seeing you for the last time, never to see you on this earth again. How. Am. I. Going. To. Do. This????

Its too much. I want to run. I want run and scream and cry and throw up...and I don't want to do any of this without you. I lied when I said I would be okay if we lost you.... I am not okay. This is not okay.... this is backwards and wrong.

I love you Mutty. So much I love you.
What do we say to death? Not today.

PS. Did you break the Time Turner? The damn thing won't work. It doesn't turn back time at all. Such bullshit.

