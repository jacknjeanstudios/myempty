---
title: 'Dig deep and muster on... '
published: true
date: '17-11-2015 18:45'
taxonomy:
    category:
        - 'Morning Mutty'
    tag:
        - reflection
process:
    markdown: true
child_type: default
routable: true
cache_enable: true
visible: true
author:
    name: 'Karen Eckstrom'
    description: 'Its getting ever closer. The holidays I mean. I cannot tell you how terrified of them I am this year. What else has your death crushed? The thought of hanging your stocking without filling it kills me. I literally feel like I could bleed tears.'
    url: '#'
    logo: x_logo.jpg
---

Its getting ever closer. The holidays I mean. I cannot tell you how terrified of them I am this year. What else has your death crushed? The thought of hanging your stocking without filling it kills me. I literally feel like I could bleed tears.

===

The thought of putting up your tree decorations and ornaments from your childhood days is going to be almost impossible to do if not impossible ... I'm not sure how to get through it. I know I can't open those totes alone. I'm not sure I can handle it at all. Dig deep and muster on... eh, Mutty?

I survived another dark period... two weeks this time. I am so paralyzed by grief I can't function. Not able to do anything other cry and work off and on. Thank God I work from home. I can cry at the computer without witnesses. What a shit place to live from. I never knew that a broken heart could physically hurt so bad. I got through it tho. I survived one more bout with the big G. Then last Friday morning I woke up, and something shifted. I was out of the darkness. Don't ask me what exactly shifted, I can't even tell you why it shifted, or if there even was a reason that it did ... but for the first time two solid weeks I felt like I wanted to talk to someone and people again.

I called Patti. Then Aunt Kim. Then Aunt Kathy... Dad cried on the phone when he heard my voice full of hope and looking forward to the future again. Friday I awoke feeling emotionally better than I had in a long time. Too long. I am Pinteresting the shit out of wedding ideas for Jos. June 4th, Mutty ...one more life celebration we will do without you. Poor Matt kept planning to propose but all this life shit got in the way. You, Grammy-pants, his aunt, Willie & Anna ... that poor guy had to dodge so much shit I'm surprised he's not wearing a flack-jacket.

This was the time of year where we did girl time together...and I miss you. I miss you so much. I am so lonely without you.

I talked to Josey this morning and asked her what she thought of filling your stocking with things from each other that we could donate. Patti Rutledge suggested we then unwrap the items we put in it, and explain where it is going and why. I don't know if I can get through that... but I know I will put something in it. You loved this time of year with us. I am so broken over the idea that you won't be here. Crushed beyond recognition. If I could skip it I would. I would wish myself right thru the next twenty years if I could.

Patti Rutledge came to see me today, and she gave me a big hug, and we visited for a couple hours. She brought lunch. It was good to be with her... I love her so much. Such a good friend and soul sister. One of the many things she is doing in her volunteering these days is to round up bell ringers for the Salvation Army. I swear that woman needs a cape. If I could stand to stand for two hours, I would do it with much love for her... in memory of you. But I'm helping her out another way, so for this year that has to be enough. As much as you hated the cold, I think you would have done this with her too just because its our Patti.

The hives are still a plague...along with the fevers and severe bone pain. We're on it tho. I can still hear you say "You wouldn't let me get away with that." So, I have been doctoring like a good girl, and doing everything we can think of to no good end. I have a rheumatology appointment the end of December to hopefully figure out the inflammation... I say its physical pain from broken heart. A manifestation of sorts. I want to be done with medical. I mean done... nothing against medical folks, but I am sick of it. Sick to death and beyond of clinics and hospitals. It has been ten long years.

Dad and I are considering selling the house. No matter where I go, you are there and not that I am running from you...but I can literally see you sitting on the furniture, sipping tea from your stupid tea set, and reading. There is no place here that I can go to shut you out. I need a fresh start. Even my office haunts me. My car. Your damn dog. The basement. You are in my walls. As much as I miss you, I want to be free of the heartache. How do I fix that?

Well kiddo, I most likely won't write again for awhile. Maybe before Christmas. Help me get thru it hunny... its my first time and I'm terrified. My first year of living without you here. Watch over us. We need all the help we can get.

I love you, Mutty. So Much, I love you.

_Love, Mom._