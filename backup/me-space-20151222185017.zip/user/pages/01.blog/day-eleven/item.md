---
title: Day 11
date: 10:16 06/22/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Good Morning Mutty,

Today is the first alone day with Josey and Willie in Plymouth and me and dad here. Breakfast was heavy-hearted albeit sustainable.

Dad and I for once in our lives are at a loss for words, and we keep asking each other "are you okay?" even though we both know things will never be okay again.

===

Okay isn't a word that applies to anything in our lives. But then it never has.

And what the fuck am I gonna say Heather, when I am meeting someone and they ask me how many kids I have????? I think I will just say "Yes" and walk away.

>... and we may have said okay but what we really meant was "Wrong sir, wrong! Under section 37B of the contract signed by him. It states quite clearly that all offers shall become null and void if, and you can read it for yourself in this photostatic copy. I the undersigned shall forfeit all rights privileges and licenses herein and herein contained et cetera et cetera... huhh fax mentis incendium gloria culpum et cetera et cetera... huhh memo bis punitor delicatum! It's all there black and white clear as crystal! ... 
> ~<cite> Willie Wonka and the Chocolate Factory</cite>.

God, that's a jerk thing to think ... But it would make you laugh. It just got too exhausting to answer any other way than "Yes. Things are okay."

I knew a man once when I asked him how he was he would answer with "Do you really want to know? or are you asking to be asking?"

You are my first thought in the morning and my second thought is 
> "Gaddammit, I'm still here." 

and then my last thought at night ... with a whole bunch of other thoughts of you in the middle. I think for a while I will need to nap often just to keep my brain function going at a human level.

It comes in waves.

I wake more exhausted than when I went to bed.

We got thru Fathers Day. 

We pretty much existed thru it. Or at least I did. We laughed a little on the front porch.

I found this quote this morning for your blog: 

>Be someone’s light when they are hopeless.”

You were always that. Even when it was you they were hopeless about. You did it with grace, baby girl. God, you taught me so much. But I still say, and will always maintain there is a time and place for a bitch switch and a mean voice. I am not going to miss that argument. No mean voices needed in heaven ... and if I know you its one vast library.
I love you Mutty. So much, I love you.

What do we say to death? When I get the fuck up, I am gonna kick the living shit out of you.

Love, Mom.

