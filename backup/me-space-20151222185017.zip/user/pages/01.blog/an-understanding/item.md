---
title: 'Please Understand'
published: true
date: '01-02-2014 13:34'
taxonomy:
    category:
        - 'letter from Mutty'
    tag:
        [letter]
process:
    markdown: true
child_type: default
routable: true
cache_enable: true
visible: true
author:
    name: 'Heather Eckstrom'
---

> Love, I’m living on borrowed time here.
I haven’t given up or anything, but let’s be realistic.
Please, since you won’t listen- read and understand that I am okay with this.

===

> I always knew this was an option.
I thought that you did too. (And that I hate being treated differently because of it.)
But I’m thinking now that maybe you didn’t and that introducing myself may have been a mistake because how could I ever prepare you in time? Why don’t I ever learn that lesson?
There is no way to prepare anyone for any kind of life with me in it.
So today you saw a little bit of truth in me.
That’s rough, huh?
I try to tell people that I break them all a little.
I don’t even try to- Somehow I just destroy some of everyone I touch.
I don’t even know how I ruined this in particular- but I know what it means when somebody runs.
Everybody runs.
But you should know that I am genuinely sorry if I hurt someone who is such a remarkable person. 
> ~ <cite> A. Jedi (aka Heather Eckstrom)</cite>
