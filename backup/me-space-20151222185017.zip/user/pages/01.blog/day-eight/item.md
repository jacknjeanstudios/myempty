---
title: Day 8
date: 07:27 06/19/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Good Morning Mutty,

Ahhhh, how you hated mornings. No getting out of the sunshine now though right? Do Angels sleep? I imagine they do not. I'm not gonna lie, there is a little satisfaction in that for me.

===

I have decided to take on your pen name, as it was you and I that formulated it. Todd and Tyler are the ones who named you Amelia, but I came up with the A. Jedi.
So if you don't mind, I think I'll use it. Like your gonna argue anyways, so there that. It's kinda fitting, no? Mama Bear to A. Jedi ... shit, I feel like I am coming up in the world. There better be a pay raise in this tho. Just sayin'.

My feet are starting to shed the water. Magnesium, a foot soak in epsom salts, Club Soda, water, water, water. water and more water ... God. So. Much. Water.
I can feel you Mutty. No one knew your "presence" better than I did. I can feel you around us. I feel you sitting curled into a ball on the sofa when we are watching tv. I feel you sitting across from my desk. Is it you? or just fresh memories? I'm going with you for sanity sake.

I told Jan this morning about me spitting my gum in your hair during my final goodbye's at your casket. As I kissed your forehead, cried and told you the things I don't even remember saying and then the gum fell out of my mouth right into your hair. Then I was dumb enough to say "Hang on Mutty, this is gonna hurt" as I pulled it out. It was a perfect moment. So us. The ridiculousness of all of it. I can think of a million moments like that. But that one, that one I think is one of the best ones.

You know how laughter thru tears is my favorite emotion anyhow. Laughter got us thru so many shitty days.

> How do you pick up the threads of an old life? 

> How do you go on?

> When in your heart, you begin to understand, that there is no going back.
There are some things time cannot mend.

> Some hurts that go too deep, that have taken hold."
> ~ <cite> LTR</cite>

Like we have always said, strength has nothing to do with it. You do what you have to because there is no other choice.... and love plays a major role in it.
I love you, Mutty. So much, I love you.
What do we say to death? Not today.
Love, Mom
PS. I am working on dad for an above ground pool... help me out with that would you?

