---
title: Three Months
date: 10:45 09/12/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Dear Mutty,

I'm on the in-between day. The day between the 3 month anniversary of your death and the celebration of your first Heaven birthday (25th birthday here). I miss you.

===

I have been pretty non-productive lately. I sat for almost two weeks immersing myself in two Netflix series. Both of which I doubt you would have approved of if not completely hated. Let's suffice it to say, dad completely hated them tagging them as "stupid".

"Ohhhh, dad." That's what I would hear you say.

Moving your medical shit out of the family room was so much harder on me than I thought it would be. I thought I was ready. It slammed me down for two solid weeks. You know me, I have to have a mission to function. For 7 years you were my mission. To keep you well, and to figure out your health. Removing that part of you was the ultimate let go.

I am proud to say I was the first one to recognize that what was ailing you was seasonally related. I am disgusted to say your care team failed to take my questions seriously. I'm still not sure how I feel about them ignoring how every spring and fall for the past 7 years, you were in the hospital somewhere. But then they are trained to look at the liver only. Frustrating. Maddening. Sad. If you gave up, I don't blame you. When your care team stops believing in you the only thing left is family love. I know we made the right decision to let you go. It doesn't mean I have to like it. It doesn't mean I have to be okay with it. Your free. That is ultimately what matters for all of us who love you. No. More. Suffering.

Josey said she wished she had one more day with you. I told her "I don't. For the simple fact I would have to let you go again, and I couldn't do it again." Whisper in her ear hunny that we are eternal beings. That just because we are not here in the physical, doesn't mean we cease to be. There are times I feel you close by me, and times I think you are gone.

I know what we have planned for tomorrow will be spurred on by the love for you here and you will be working in the background towards doing all the things you wanted to do here, from where you are now. It's pretty exciting stuff. The idea seeds were planted the day of your funeral by your friends who love you - Cameron, Chandler and Jimmy. We're going to take it to a much grander scale. Tomorrow we are going to talk about it. Its going to give us focus on one of the hardest days we have to face without you. Your birthday.

It's a very big deal.

For the most part we are doing okay. Fair to middling I'd say. For a while there I wasn't sure I'd throw soap ever again, and now I am thinking about it, which will result in me throwing soap eventually. Christmas is coming, and Terry and I had a good talk about connections in the pool a few weeks back.

Dad's out of toothpaste so I have to make some today. It works so well, even the uptight swede is asking for some more. That's how I know its good. I know your happy to see we are finding each other again.
Well kiddo, time is a-wastin' and I have to get busy and get things in order here for tomorrow. I know you will be with us, like you always are.

I love you, Mutty. So much, I love you.

Love, Mom

