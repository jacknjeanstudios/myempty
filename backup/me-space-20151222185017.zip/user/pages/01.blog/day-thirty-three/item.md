---
title: Day 33
date: 22:50 07/14/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Dear Mutty,

I wrote once this morning but then I accidentally deleted it. No recovery on Facebook...its kind of like you...here one minute, gone the next. Done deal.

===

Today was a good day, Heather. Probably the best alone day I have had since you left. Minimal tears, but then I cried at least once a day before you died so I will look at that as progress.

I have decided that I am just going to take it as it comes for a while. The empty places where you were are okay as empty...and in those places I plan to fill them with things that we talked of doing...or things that will bring this all to a close for me so I can move forward. You know me, not long on patience, eh Mutty? I feel like I should be doing something and not that I am doing nothing but I have never done things for just me, you know? I don't know how to be Karen-centric. So I have some work to do. That's the hardest part I think in all of this- missing you, and having to find me. I don't know if I have ever been Karen-centric in my life.

You know - married at 17, kids at 22... and not that its just me now cuz I still have Dad on a daily basis, but on the alone days it is just me. Being alone never scared me before - I actually remember the first time I had a weekend to myself after you kids came along and the sheer bliss of it ... but now that I see the mortality of all those I love I am scared shitless something will happen to one you and then what... I will go insane, that's what. I cannot take one more major loss in my life.
I call dying next.

Yesterday wasn't a complete loss either. I slept. Jamie cleaned out the car for me over the weekend in hopes it would help me to get in it to drive it. I still can't do it. She left your sweater by my chair so I held it and went to sleep with it on your sofa you slept on for that year you were yellow. I am afraid of the day your scent will be gone even tho someone sprayed it with Fabreeze. I woke up and weeded both flower beds, and watered your tree, and dad and I swam in the murky pool.

Cleaner than the lake...but not as clean as I would like. Stupid iron.
Work is slow, but I think that is actually okay. I am just taking it as it comes...finding my legs again. Taking a few online courses. My heart is in very little these days. How am I gonna find the same passion that I had in helping you to be okay? What a colossal shit sandwich to have to swallow...to work so hard and then you die anyways. Dad and I talked about how if you had died on the last xplant how much easier we think it would have been.

No going back.

I heard the katydids sing for the first time today.... 6 weeks til first frost. I don't mind saying I need the flowers for a lot longer than six weeks before the days turn to snow.

Time will slip by just as fast as it always has...and I wonder Heather, I wonder if the ache I feel in my heart will be as intense ten years from now as it is today? Or will I think in ten years that I am that much closer to seeing you again? I hope I still have the ability to see the glass as half full.

> But I must admit, I miss you quite terribly. The world is too quiet without you nearby. I go to bed early and rise late and I feel as if I have hardly slept." ~<cite> Lemony Snicket</cite>

I love you, Mutty. So much, I love you.

Love, Mom

