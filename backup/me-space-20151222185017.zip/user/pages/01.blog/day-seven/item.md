---
title: Day 7
date: 23:10 06/17/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Good Morning Mutty,

It has been seven days since you left. I can barely remember the past few they are such a blur. The foot traffic here is tapering down. I am okay with that. While I am scared to death of my first "alone" day, I am curious to see just how well I do. I keep thinking if we left anything unsaid, and so far I have yet to come up with one thing that I forgot to tell you. We said it all didn't we? Didn't we?

===

God, I am so thankful for that. The gift of knowing we said it all. How do people do this who don't have that gift? If I could tell the world anything it would be to say it. Say it now. Say all of it. Have the hard talks, and the deep discussions. Cry thru them, and feel the love. Let yourself be loved, and love others. Why don't we talk about stuff like that with each other? Why is it so hard to do? When its all said and done the only thing left then is the ache in the heart. No regrets, hunny. No regrets.

Dad wept yesterday, sitting on the front porch after weed whacking.

We talked about the discussion he had with you about a week or two ago. You know, the one where he told you if you don't eat, you're going to get sick and you told him "I'm already sick, dad." God Mutty, how long did you hurt, and how bad did you hurt before you left?

I will feel better, I think, when we get you home. I have a place all picked out for the urn. I don't think I will ever inter you. You belong here with us. You felt safe with us, so here is where you will stay. I told dad today that when we die, we will keep you with us then, too.

It looks as though we will be taking down that big pine in the center flower garden and planting your memorial tree. I suppose I will have to refer to it as Mutty's Garden.

You get your weirdness from me even though yours was dorky. Creative souls, eh, Mutty?

Did I tell you Josey was watching the "Harry Potter Marathon Weekend" without realizing it was a DVD playing on repeat, and its not the weekend? Ugh, we are going to be a mess for a while.

>There are so many beautiful things to see and experience in the world, why would anyone want to waste their time hating others for trying to do that in their own way?

> ~ <cite> Michael Lottner</cite>

I miss you, Mutty. So much I miss you.

What do we say to death? You're a bastard, so fuck-off.

Love, Mom

PS. Sleep isn't going so well, and my feet are the size of footballs. Any chance you could help with that?

