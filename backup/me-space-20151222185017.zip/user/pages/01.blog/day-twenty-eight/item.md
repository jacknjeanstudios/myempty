---
title: Day 28
date: 07:58 07/09/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Hi Mutty,

This morning started with your favorite wren singing at the top of his little lungs... I told dad how much you hated that bird because he started singing at sunrise. I think that bird might be a direct cause of you hating mornings.

===

Last night was a complete and udder failure and near disaster. Dad and I cried until after midnight. He had a rough night at work and my night consisted of me not being able to get into the car to get the stuff we got this morning because you and I literally went everywhere together... and you are still all over my car..and I just can't do it. It still is just too raw.

A certain someone called Dad and just couldn't understand why he didn't go on his trip to Canada two weeks ago. I get it, Hunny. I get some people will say really stupid things... mouth vomit. You know? They don't know what else to say... but what's a really bad idea is to point out shortcoming or missed opportunities when someone is so raw with pain and grief. Family doesn't get to have a get out of stupid free card... or deck. See, that's how you know I love Dad... I want to defend him, and lay into the person ... but sometimes you just can't fix stupid, no matter how hard you try. I said I was sorry that the person is such a shit when he has been there for them always. Then we cried some more. He's hurting so much. I want to use my mean voice on the ass-hat that hurt him.

> "Courage: I understand that everyone has their own unique path and challenges." ~<cite> Today's Angel Card I drew for you.</cite>

Dad said he hung up the phone and all he could see was your face, at the hospital, on the vent. How sick you were. Your last breathes... and then nothing. You were just gone. He said he cried for a good long while and was thankful no one was there to see him cry. My heart aches for him. We hurt for each other. He thought that morning, that there was still hope you'd recover.

> "You held my hand when it was cold
When I was lost, you took me home
You gave me hope when I was at the end
And turned my lies back into truth again
You even called me friend." ~<cite> Anne Murray - You Needed Me</cite>

You and I, Mutty, we said everything there was to say...I still cannot think of one thing left unsaid... but dad, he's hurting. Dad said we had a special bond... and while that might be true... I know how much you loved him always and I know you now know how much he loves you.

Why do we doubt these things in death? Is it because death is such a life shattering experience in all aspects that none can be prepared for it? I mean we always knew it was possible.

We got up early on a mission to conquer the water in the pool. PH balancer at Runnings, and Pool vac at Menards. I did get the ladder put together and went into the water (still not clear). Maybe next year we can afford a patio that will stabilize and level everything.

We got as far as the ladder put together and me skimming the pool for the bugs, and the rest will wait until Monday. Maybe Willie will work on it for me while we are gone.

Josey and I talked for a while on the phone tonight. She misses you so much. Somehow our conversations still end up on you...and us crying...and often laughing.

Willie called but we were outside and dad was mowing so I didn't hear the phone ring.

Things are moving along... and some times...well most times... it just seems like you are away at a friends house, or sleeping in the cave... or sitting and watching tv curled in a ball.... somehow it still doesn't seem real.

Millie has recovered to her bouncy and yappy self... so I guess that means we all get to live a little longer.

> “I promise you one day, flowers will grow from these scars with their roots twisting deep. I’ll show you that even in the most broken of places, life finds a way.” ~<cite> unknown</cite>

I miss you Mutty. I miss you horribly and I love you. So much, I love you.

Love, Mom

