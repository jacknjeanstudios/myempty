---
title: Day 32
date: 20:22 07/13/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Good Morning Mutty,

Coffee this morning is good because I am drinking from the cup you gave me for my birthday a few years ago. We finally made the journey up north to see Grammy.

===

We didn't talk too terribly much. There again... I think everything that needs to be said has been said between us. She is ready to come and be with you. I doubt I will see her alive again. She cried and said how tired she was. I told her that if she got the chance to go...she should go. Her life has been no easy feat... and a little peace for her soul would be good.

Dad and I rode up the north shore on Saturday. The wildflowers were in their full glory along the roadsides. I now want to get some lupines for my own garden. It won't be long now and the morning glories you and I planted will bloom. Your spices that you had to have are doing okay, but there again... I have no idea what to do with them.
I asked Aunt Sandy if she would help me make quilts out of your clothes, and so I think that's what we are going to do with them.

> “But still, I find the need to remind myself of the temporariness of a day, to reassure myself that I got through yesterday, I’ll get through today.”
~<cite> Gayle Forman, Where She Went</cite>

Friday was such hard day for me. I pulled your last outfit you wore out of my laundry to fold. I hugged it and cried my soul out on it. Its those things that catch me so off guard. I walked thru the kitchen the day before that, and there in a corner was a wad of your beautiful hair that your meds raised so much hell with. That would gross out most people, but to me it was evidence you were here.... and one day all those little reminders will be gone and then it will be only memories...and while I am thankful for them, it is heartbreaking too.

Still so raw. Still hurts so much. Still so unreal.

> “Recently I’ve been passing the days not living them.” ~ <cite>unknown</cite>

I can remember telling you with each relationship you formed that it was important not to lose who you were in that person. Its important to keep your own identity. Because if you lose it in someone else by becoming what you think they want, one day you will grow to be unhappy.
I didn't even take my own goddamn advice. You were such a big part of me... and now I am lost.

Tomorrow will be a better day.

I love you Mutty. So much, I love you.

Love, Mom

