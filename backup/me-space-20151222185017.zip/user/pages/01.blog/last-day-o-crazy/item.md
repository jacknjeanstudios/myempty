---
title: The Last Day of Crazy
published: true
date: '16-06-2015 07:06'
taxonomy:
    category: 'Morning Mutty'
    tag:
        [journal, comforting]
process:
    markdown: true
child_type: default
routable: true
cache_enable: true
visible: true
---

Good Morning, Mutty.
Well today is the last day of this craziness and party that everyone cries at. I was thinking last night how it used to be a funeral in three days. I am amazed we were able to get our shit together in 5.

I find myself comforting all the souls you touched. People tell me to let others carry me now, and that I carried you for so long and now its my turn to be carried. I don't think they understand that we carried each other. I'm not the non-carrying kind anyways. People say they are sorry... I'm not sorry. If they could have seen how you suffered just to get one IV line going. If they could have witnessed some of the indignation of a few of the people who hold a doctorate degree, but have no clue on what being a doctor really is... The humiliations. The pain. I'm sorry you had to endure that. I'm sorry for that. That's what I am sorry for... but not that you're gone. I will miss you, but you my baby are free of all this bullshit.

On the flip side of that, soooo many people who cared for you, who touched you. Whom you touched. It is quite something Heather that the ones you think would not have been touched by you even a little, like the security guard who dropped a diamond necklace into the card basket with the "Footprints" poem, he wept for us... it is those things that shine bright to me that the positive, and loving people far outshine the shadows of those who went for the prestige of the degree rather than the truth of it.

And do you know that it has been seven years nearly to the day that I stopped writing because the near loss of you then shut me down so badly that I couldn't and now it seems I have a life time of material and ruminations that I need to share with the world? I will share every dark place that you brought light to... especially my soul. This came so full circle.

How did you end up to be my child hunny? How is it that God gave you to me? I was not worthy of it, and yet you were mine first. You will always be mine first.

I love you Mutty. So much , I love you.

What do we say to death? Not today.
