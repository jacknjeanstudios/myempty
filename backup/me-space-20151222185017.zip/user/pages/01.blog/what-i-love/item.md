---
title: 'What I Love'
published: true
date: '26-06-2015 12:09'
taxonomy:
    category:
        - 'letter from Mutty'
    tag:
        [letter]
process:
    markdown: true
child_type: default
routable: true
cache_enable: true
visible: true
author:
    name: 'Heather Eckstrom'
---

> What I Love

> I love the way that chocolate tastes.

> I love the sound of my grandma laughing, knowing that the moments she does are running out.

> I love genuinely liking people. 

===

> I like that, when I’m nice to others, they feel special. Even though it’s a little sad that a stranger makes them feel special. Isn’t that the job of a loved one? I’m still happy to do it.

> I love things that smell good. But I love nothing more than the natural smell of fresh air- like on a cold winter morning or a wet spring afternoon.

> I love every moment that I’m breathing.

> I love living on borrowed time. Mostly because it’s the only way I can be alive. That used to be bittersweet for me, but not anymore.
I love hugging people. Like, real hugging. Not an awkward lean in, pat on the back kind of hug. The kind where you just hold on to someone with both arms for dear life and get the privilege to hear their heartbeat up close for a few seconds.

> I love proving to people that they are good and lovable. I will always do that.

> I love being at peace with my very existence, wherever I am existing at any moment.

> I love all of these things. And many more I’m sure. They feel real, and right, and true. But they belong to no one but me.

> I don’t understand why I feel like I’m constantly being told that unless love is exclusively shared with one other individual, it’s not love.

> Cause I don’t know how to do that. I don’t know how to focus my love.
Sure, there are so many people I could love. Not in a passing way like usual. But genuinely love just one person day in and day out and be loyal and gracious and generous to them until the end of forever. I’m sure I would be very happy to do that, too.

> But I don’t expect it. The world tells me I’m far too okay with being just me. That if someone wants me to be theirs forever, I’m okay with it- but that I don’t need it.

> I don’t need it. I don’t even know if I want it.

> I love being a loving person. But loving one person… I don’t know. I don’t know if I could ever love that.

> ~ <cite> A. Jedi (aka Heather Eckstrom)</cite>
