---
title: Day 22
date: 21:16 07/03/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Dear Mutty,

I'm not in the mood to write or talk tonight... its been a disappointing day.
I want to just go to sleep and see if tomorrow is a better day.

===

> “What do you say when the feelings don’t fit into words?” ~<cite> Tammara Webber, Between the Lines</cite>

... and what do you do when they do?

Talk.

Write.

Sing.

Cry.

Sleep.

Sit on your bed, hug your pillows and try hard to remember your scent and sound ... Or die.

I'm still here.

I love you, Mutty. So much, I love you.

Love, Mom
