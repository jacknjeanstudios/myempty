---
title: Day 25
date: 11:47 07/06/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Good Morning Mutty,

I didn't write yesterday. I chose to just exist. Not good, but it is what it is. Today, although raining and sad looking will hopefully be better.

===

Dad is on afternoons. The rain won't help his day... you know him, if he can't be puttering he will be crawling the walls. I, on the other hand have plans to work...and purge you out of my office.

All the medical bills and papers are getting gone thru and put into a basket for the burn pit.

We peopled on the 4th, although I really didn't think I could do it. I opened the back seat of the car in search of my sandals, and there in a ball was your sweater... and I picked it up and hugged and smelled it and that of course opened the flood gates. I had to sit in the truck at the lake for 10 or 15 minutes to stop the water works before I could people. So I am on a mission now to hide the reminders of you from our old life... all the trips to the University - you are all over my car...and for real if I could move from this house, and get a different car - I would - It just hurts so much. It is all reminders to us that you are no longer here in our physical world.

Dad and I went to DQ last night. Neither of us are eating well... Dad said he was hungry for ice cream (he is always hungry for ice cream) so we gathered up the dogs and went to Litchfield.

'What lies behind us, and what lies before us, are tiny matters compared to what lies within us." ~Ralph Waldo Emerson

On the way home Dad said the only thing that keeps him going is the fact you would not want us to be sad...and you would want us to keep going. I met that with thoughts of "well you know what? She doesn't get a say anymore. I am sad. I need to be sad until I am sick to death of sad, and then I will be something else. But for right now, I am annihilated by grief because a very large part of my life is gone... you were such a large part of my life and my daily routine.... and trying to fill those holes is going to be impossible for me right now. I was fired by death... and that really fucking sucks, Heather Marie Eckstrom!"
Verbally, I agreed with him...and cried with him.

It has been a decade from hell.

I talked to grammy-kins yesterday, she called. She asked how I was doing... and I think the only words to put to it is existing semi-productively. Day to day things are mostly stable.... but moving forward. Ahh, now there's the rub. I truly do not know where to start, to rebuild my life. I have never been knocked down this damn hard in before... and I am at a loss as to what to do to even begin anew much less get up.

Wallowing, is sometimes needed in life. To bathe in your own quagmire, whether it is grief, or fear, or pain, or tears, or loss ... it is cleansing. It is needed to rise from the ashes, and to be able to move forward. But, it is staying there that can become the problem. I have no intentions of staying in the quagmire of grief... but right now... I have no idea how to move beyond it either. So, endurance it is.

> "Out of suffering have emerged the strongest souls; the most massive characters are seared with scars." ~<cite>unknown</cite>

Millie is sick... no idea what is going on, but she isn't moving much and her food intake is minimal. I literally had to pull her out from under the bed in your old room upstairs last night. She is drinking... but we are both worried about her...I think it might be grief... or the pig ears. She eats her cookie, but then she steals Maggie's and eats hers, too.

We slept in the family room, her and I... just like I used to do with you. I miss you.

For realz kid, I can't take the loss of one more something in my life right now. I have had losses before...but this... the loss of a child, even though you are 24... is just on a whole different level of loss and pain. Parents and Grandparents, you expect to lose even if not prepared for it.... but a child - even one who was as sick as you were - its on a whole different level of pain... it is a literal physical ache...and it is palpable.... and it ebbs and flows. And sometimes it crashes into you when you least expect it.

Well, Mutty, my Monday is calling, and I should answer it. Maybe I'll go to Skyrim instead... or maybe I will sleep. At least I have options.

I love you, Mutty. So much, I love you.

Love, Mom

