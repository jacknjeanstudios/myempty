---
title: Day 19
date: 08:00 06/30/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Morning Mutty,

Yesterday was not entirely an alone day. Patty was here. The main floor is back in shape again. Today I am hoping to get the upstairs whipped into shape. Then back into a routine. Routines are good.

===

I stayed busy most of yesterday, and I think a nap will be in order today. Once again I am up at 5:30 and that's not a bad thing when you go to bed at 10... unfortunately I still hold late night hours.

Now begins the business side of all of this, Mutty. Sending your death certificates to the powers that be. I wonder how people who have no one to notify their debtors of their demise notify them? The phone has stopped ringing... just once I would like a bill collector to call so that I can put the phone by your urn for them to speak to you. I think they must all be tapped into a database that automatically notifies them of such things. That's crap. One last "In your face" would have been nice.

It’s one of those things that people fail to understand when something like this takes place... suddenly you are fighting the system for medical shit but life... the other side of life- the one you used to know ... keeps going and often-times juggling both can be so overwhelming.

It got that way for me so many times. Overwhelming. I tried not to let you see how exhausting that side of it was... but then you called Caremark that one day and they transferred you 5 different times before hanging up on you. You were so pissed...and then you sat in the chair across from me and cried and apologized. Those are the things you have to learn to roll with... they come at this from the perspective of it’s not a "serious" illness, and that it’s something standard. You were so not standard.

I hate that company. I hate them with a passion. Even after we took it to 3M HR, to over-ride them so the specialty pharmacy could handle your meds, they still called. Still insisted we order from them. The bastards.
If I let you down in any way, I am sorry. The hard part about being a mom, is we are still human. Somehow, as children, we fail to understand that.

I'm guilty of it myself.

We got your flower books yesterday, and all the pictures that were taken at the funeral. Dad and I cried again sitting at the kitchen table as we looked thru them.

We sat on the porch for a bit last night. Dad cried more, then I cried because he cried. He said he still had hope that you would be okay the morning you died when he came home to get the dogs and bring them to Josey and Willie's.

I don't know how I knew Mutty, but the day before, I knew this was it. When I saw you bolt to the end of the bed... I knew then you were leaving and all I could do when I got to the U was to sit with you and tell you that I loved you and that I wasn't ready to do life without you. I knew you would never open those pretty brown eyes of yours and talk to me ever again. I'm still not ready for this to be true.

I made hummingbird nectar. I think I boiled the water ten different times and forgot it each time. I started with four cups, there were two left when I opened the microwave the last time. I ended up putting the water in a kettle on the stove. Ultimately it was faster anyways.

Well Mutty, I have bled a little more of my soul onto the screen... and I am tired so maybe I will see you in my dreams.

> I always worry that I will never believe in myself the way that my children have believed in me." ~<cite> Me</cite>

I love you, Mutty. So much, I love you.

Love, Mom

