---
title: Day 23
date: 09:24 07/04/2015 
taxonomy:
    category: 'Morning Mutty'
    tag: [journal]
---

Good Morning Mutty,

Well, I am back to mornings because today is the fourth and maybe we won't come home early tonight... and I am fast coming to the conclusion there is really no "good" time to write these letters to you.

So I will write when I feel like it.

===

I woke and looked out the window and dad was sitting at the picnic table alone just staring into the smoldering fire ...and so I got up to go sit with him. You are on our minds non-stop. I don't need to ask him to know what he is thinking.

I went out and sat with him... and I cried.

You are literally everywhere we look or go. You are in the cucumbers in the garden; the Essential Oils section in the organic foods section; the watermelon bin in the produce section; Sleepy Time Tea in the Coffee isle; Swiss Cake Rolls in the junk food isle; Corn Dogs at the Deli; there is not one place we can go that doesn't remind us of you in some large or small way.

I went down stairs yesterday intending to look for something in the laundry room ...and made the dire mistake of sticking my head into your room... I found Willie's keys there.... but sat on the bed for a good long while and cried. Hugging your quilt and smelling your pillows. I think that set the tone for the whole day.

How is it I can be disappointed you aren't here when we are the ones who decided to let you go?

I suppose I am going to have toughen up and go in there every so often and clean your room or it will get to look like Ms Havisham's banquet room.

I have no intention of becoming like her. Just sayin'.

> “Make yourself a priority once in a while. It’s not selfish. It’s necessary” ~<cite> unknown</cite>

We are suppose to go to Grammy's this coming Friday. I told Dad I am scared of just existing there. Isn't that a bitch thing to say? She is probably not going to live to see next spring but the idea of just sitting and being there is scaring me, because if I can't stay busy doing SOMETHING, I may go insane. I don't want the pain to catch up to me and if I stop it will slam into me like a freight train straight out of hell.

I sat this morning and added up your death date numbers. 6+1+1+2+0+1+5 =16 = 1+6 = 7. The number of completion in the bible.

This is the actual crazy shit I do now... or still... but with more attention.

Frodo: "I wish the ring had never come to me, I wish none of this had ever happened".

Gandalf: "So do all who live to see such times, but that is not for them to decide. All we have to decide is what to do with the time that's been given to us."

I'm still here. Breathing. Trying to find my way thru this hell ... and finding your dad again. We may not have perfect love heather...but we have staying power... and we rely on each other to get us thru shit times like these even though we might womp each other in the process, like the Womping Williow in Harry Potter.

And we are scared for each other... I worry on him...and he worries on me.

That should make you smile.

I love you Mutty. So much, I love you.

Love, Mom

