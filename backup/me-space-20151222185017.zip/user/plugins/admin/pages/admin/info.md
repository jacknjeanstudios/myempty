---
title: PHP Info

access:
    admin.settings: true
    admin.super: true
---
