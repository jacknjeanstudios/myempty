---
title: Error Log

access:
    admin.logs: true
    admin.super: true
---
